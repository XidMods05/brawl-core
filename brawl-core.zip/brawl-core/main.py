# Main file

from datetime import datetime
from threading import Thread
from admins.network.adminserver import AdminServer
from players.network.playerserver import PlayerServer

if __name__ == '__main__':

    # vars
    timenow = datetime.now()

    # code
    print("""
          THIS BANNER
          BY THE WAY IT SOURCE BY ROMASHKA AND XID
          """)
    print("\n")
    print("core will be launched.")
    print(f"at {timenow}.\n")

    class Players(Thread):
        def run(self):
            PlayerServer(("0.0.0.0", 9339)).start_server()

    class Admins(Thread):
        def run(self):
            AdminServer(("0.0.0.0", 9119)).start_server()

    pls = Players()
    ads = Admins()
    pls.start()
    ads.start()

else:

    print("not main or hack server!")
    print("exit.")
