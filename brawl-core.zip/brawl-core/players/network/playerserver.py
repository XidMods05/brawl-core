# Protocol: TCP network

import urllib.request
import socket
import select
import json
import os
from datetime import datetime
from players.network.receiver import Receiver


class PlayerServer:
    def __init__(self, addr):
        self.addr = addr
        self.socket = socket.socket()
        self.socket.setblocking(0)
        self.inputs = {self.socket: None}
        self.admin_ips = ["127.0.0.1"]
        self.whitelist = ["127.0.0.1"]
        self.tim = {}

    def disconnect(self, socket):
        if socket in self.inputs:
            print(f"disconnect from PlayerServer!")
            socket.close()
            self.inputs.pop(socket)

    def start_server(self):
        self.socket.bind(self.addr)
        self.socket.listen(5)
        print(f"Player server started! To: {self.addr}.")
        while True:
            read_fds, write_fds, except_fds = select.select(self.inputs, [], self.inputs)  # [] - output
            for i in read_fds:
                if i == self.socket:
                    client, addr = self.socket.accept()
                    client.setblocking(0)
                    # check
                    if addr[0] not in self.whitelist:
                        url = "https://ipinfo.io/" + addr[0] + "/json"
                        sender = urllib.request.urlopen(url)
                        infoip = json.load(sender)
                        if infoip["bogon"] == "true":
                            print("dev ip - " + addr[0])
                        else:
                            if infoip["country"] not in ["RU", "AZ", "KZ", "AM", "BY", "KG", "MD", "TJ", "UZ", "TM"]:
                                print("war country: " + infoip["country"] + " for ip - " + addr[0] + " #ban")
                                os.system(
                                f'sudo iptables -t filter -A INPUT -s {addr[0]} -j DROP && sudo netfilter-persistent save')
                                socket.close()
                                pass
                            else:
                                print(f"new connection from {addr[0]}:{addr[1]} to PlayerServer")
                    if addr[0] in self.whitelist:
                        print(f"new connection from {addr[0]}:{addr[1]} to PlayerServer #white user")
                    print(f"{addr[0]} start checked!")
                    if addr[0] in self.tim:
                        print(f"{addr[0]} 45% checked!")
                        if int(datetime.timestamp(datetime.now())) - self.tim[addr[0]] < 3:
                            os.system(
                                f'sudo iptables -t filter -A INPUT -s {addr[0]} -j DROP && sudo netfilter-persistent save')
                            socket.close()
                            print(f"{addr[0]} 100% checked! #ban")
                        else:
                            self.tim.update({addr[0]: int(datetime.timestamp(datetime.now()))})
                            print(f"{addr[0]} 100% checked! #normal")
                    else:
                        self.tim.update({addr[0]: int(datetime.timestamp(datetime.now()))})
                    if addr[0] in self.admin_ips:
                        print("admin logged into PlayerServer! ip - " + addr[0])

                    self.inputs[client] = Receiver(client)
                else:
                    if i in self.inputs:
                        try:
                            result = self.inputs[client].receive_message()
                            if result == -1:
                                self.disconnect(i)
                        except:
                            self.disconnect(i)
