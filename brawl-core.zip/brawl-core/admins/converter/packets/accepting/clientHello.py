from admins.converter.piranhamessage import PiranhaMessage
from admins.converter.packets.departing.serverHello import ServerHelloMessage


class ClientHelloMessage(PiranhaMessage):
    def __init__(self):
        super().__init__()
        self.id = 10100

    def decode(self):
        pass  # decode

    def process(self, con):
        con.messaging.send(ServerHelloMessage())
