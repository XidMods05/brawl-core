from admins.network.adminserver import AdminServer

class Admins:
    print("admins folder initialized!")