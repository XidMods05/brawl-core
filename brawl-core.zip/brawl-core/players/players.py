from players.network.playerserver import PlayerServer

class Players:
    print("players folder initialized!")
