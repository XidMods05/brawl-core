from players.converter.packets.accepting.clientHello import ClientHelloMessage

packets_list = {
    10100: ClientHelloMessage
}

class FindMessage:
    def convert(m_type):
        if m_type in packets_list:
            return packets_list[m_type]()
        return None

    def packets(self):
        return 0
